var issue = [
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Permitted-Cross-Domain-Policies', 'fetched': true, 'code': 403, 'len': 146, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'dir': 'i0' }
];
