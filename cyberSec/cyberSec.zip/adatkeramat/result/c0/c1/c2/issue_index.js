var issue = [
  { 'severity': 0, 'type': 10901, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 400000, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 400000, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'dir': 'i1' }
];
