var child = [
  { 'dupe': true, 'type': 4, 'name': 'node_modules', 'dir': 'c0', 'linked': 1, 'url': 'https://adatkeramat.tangerangkab.go.id/css/api/node_modules/', 'fetched': true, 'code': 404, 'len': 59956, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x43ef9884 },
  { 'dupe': true, 'type': 8, 'name': 'r', 'dir': 'c1', 'linked': 1, 'url': 'https://adatkeramat.tangerangkab.go.id/css/api/r', 'fetched': true, 'code': 404, 'len': 59910, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 2, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x509fb94f }
];
