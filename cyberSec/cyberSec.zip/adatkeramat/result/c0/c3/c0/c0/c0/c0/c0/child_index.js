var child = [
  { 'dupe': true, 'type': 4, 'name': 'Server', 'dir': 'c0', 'linked': 1, 'url': 'https://adatkeramat.tangerangkab.go.id/images/api/node_modules/@adonisjs/framework/src/Server/', 'fetched': true, 'code': 404, 'len': 60089, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xdef3216a }
];
