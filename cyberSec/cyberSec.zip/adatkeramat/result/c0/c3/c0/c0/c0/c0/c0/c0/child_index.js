var child = [
  { 'dupe': true, 'type': 32, 'name': 'index.js', 'dir': 'c0', 'linked': 1, 'url': 'https://adatkeramat.tangerangkab.go.id/images/api/node_modules/@adonisjs/framework/src/Server/index.js', 'fetched': true, 'code': 404, 'len': 60113, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xffdfffff }
];
