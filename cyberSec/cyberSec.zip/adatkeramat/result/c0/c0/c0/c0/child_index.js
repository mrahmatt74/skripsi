var child = [
  { 'dupe': false, 'type': 4, 'name': 'framework', 'dir': 'c0', 'linked': 1, 'url': 'https://adatkeramat.tangerangkab.go.id/api/node_modules/@adonisjs/framework/', 'fetched': true, 'code': 404, 'len': 60036, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 3, 'issue_cnt': [ 0, 0, 0, 3, 0 ], 'sig': 0x4bab8806 }
];
