var issue = [
  { 'severity': 3, 'type': 40101, 'sid': '0', 'extra': 'injected \x27\x3csfi...\x3e\x27 tag seen in HTML', 'fetched': true, 'code': 404, 'len': 60242, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'dir': 'i0' }
];
