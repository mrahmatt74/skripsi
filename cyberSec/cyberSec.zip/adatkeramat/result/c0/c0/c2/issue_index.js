var issue = [
  { 'severity': 0, 'type': 10405, 'sid': '0', 'extra': '', 'fetched': true, 'code': 301, 'len': 179, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'dir': 'i0' }
];
